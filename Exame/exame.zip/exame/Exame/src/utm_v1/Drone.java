package utm_v1;

import java.util.Observable;

public class Drone extends Observable {
	
	private String self_status;
	private int id;
	
	public Drone(int id){
		this.id = id;
		this.self_status = "Rec�m criado";
	}

	public void setNewStatus(String novoStatus) {
		this.self_status = novoStatus;
		setChanged();
		notifyObservers(true);
	}
	
	public String getStatus() {
		return this.self_status;
	}
	
	public int getID(){
		return this.id;
	}
	
}
