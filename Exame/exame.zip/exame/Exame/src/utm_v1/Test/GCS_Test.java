package utm_v1.Test;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import utm_v1.Drone;
import utm_v1.GCS;
import utm_v1.UTM_CTR;

public class GCS_Test {

	GCS gcs = new GCS(1);
	
	@Mock
	private Drone drone;
	
	@Mock
	private UTM_CTR utm;
	
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		drone.addObserver(utm);
	}
	
	@Test
	public void GCS_UpdateMethod_WhenCalledDisplayShouldChange() {
		/**
		 * Quando o GCS chama o m�todo update este deve mudar seu display
		 */
		Mockito.when(utm.getStatusForID(1)).thenReturn("ERRO 404");
		gcs.update(utm, 1);
		assertEquals("Drone 1 novo status �: ERRO 404",gcs.getDisplay());
	}

}
