package utm_v1.Test;

import static org.junit.Assert.*;
import org.junit.Test;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import org.junit.Before;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import utm_v1.Drone;
import utm_v1.GCS;
import utm_v1.UTM_CTR;


public class UTM_CTRTest {
	UTM_CTR utm = UTM_CTR.INSTANCE;
	
	@Mock
	private GCS gcs;
	
	@Mock
	private Drone drone;
	
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void UTM_UpdateMethod_WhenCalledShouldDisplayDroneStatus() {
		/**
		 * Testando o m�todo update do UTM_CTR, este m�todo � chamado quando o Drone executa o m�todo NotifyObservers().
		 * Aqui em especial estamos interessados na mensagem que o UTM ir� transmitir para o GCS
		 */
		Mockito.when(drone.getStatus()).thenReturn("N�o � da sua conta!");
		Mockito.when(drone.getID()).thenReturn(66);
		utm.update(drone,2);
		assertEquals("UTM_CTR informa:  Drone 66 mudou de status para N�o � da sua conta!", utm.getDisplay());
	}
	
	@Test
	public void UTM_UpdateMethod_WhenCalledAllGCSSHouldCallUpdateMethod() {
		/**
		 * Testando o m�todo update do UTM_CTR, este m�todo � chamado quando o Drone executa o m�todo NotifyObservers()
		 * Aqui em especial estamos verificando se o m�todo update dos observadores do UTM s�o chamados.
		 */
		Mockito.when(drone.getStatus()).thenReturn("N�o � da sua conta!");
		Mockito.when(drone.getID()).thenReturn(66);
		utm.addObserver(gcs);
		utm.update(drone,2);
		verify(gcs, times(1)).update(utm,66);
	}
	
	/**
	 * ITEM C
	 */
	@Test
	public void UTM_MustBeSingleton(){
		/**
		 * O UTM_CTR deve ser um singleton, ent�o quando eu instanciar outro utm ele deve ser identico ao utm j� instanciado e m�todos que envolvem um utm devem afetar 
		 * o outro utm afinal ambos apontam para o mesmo objeto
		 */
		UTM_CTR utm2 = UTM_CTR.INSTANCE;
		assertTrue(utm2 == utm);
		
		Mockito.when(drone.getStatus()).thenReturn("N�o � da sua conta!");
		Mockito.when(drone.getID()).thenReturn(66);
		utm.update(drone,2);
		assertEquals("UTM_CTR informa:  Drone 66 mudou de status para N�o � da sua conta!", utm2.getDisplay()); //Notar que estou chamando o display de utm2!
		
		
	}

}
