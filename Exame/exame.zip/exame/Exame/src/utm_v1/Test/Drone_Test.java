package utm_v1.Test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import utm_v1.Drone;
import utm_v1.GCS;
import utm_v1.UTM_CTR;

public class Drone_Test {

	Drone drone = new Drone(1);
	
	@Mock
	private GCS gcs;
	
	@Mock
	private UTM_CTR utm;
	
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		drone.addObserver(utm);
	}
	
	@Test
	public void Drone_SetNewStatusMethod_WhenCalledUTMShouldCallUpdateMethod() {
		/**
		 * Quando o Drone muda o seu status, o UTM deve chamar o m�todo update.
		 */
		drone.setNewStatus("BANZAI!");
		verify(utm, times(1)).update(drone,true);
	}
	
		
		
	}


