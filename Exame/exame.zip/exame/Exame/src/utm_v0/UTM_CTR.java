package utm_v0;

import java.util.Hashtable;
import java.util.Observable;
import java.util.Observer;

class  UTM_CTR extends Observable implements Observer   {

	Hashtable<Integer, Drone> _drones = new Hashtable<Integer, Drone>();
	Hashtable<Integer, String> _status = new Hashtable<Integer, String>();
    //Observable revistaInformatica;
	
	public static final UTM_CTR INSTANCE = new UTM_CTR();
    private UTM_CTR() {}
	
	public void addDrone(Drone drone){
		String status = drone.getStatus();
		int id = drone.getID();
		_drones.put(id, drone);
		_status.put(id,status);
		drone.addObserver(this);
	}
	
	@Override
	public void update(Observable D, Object arg1) {
		if (D instanceof Drone) {
			Drone drone = (Drone) D;
			String status = drone.getStatus();
			int id = drone.getID();
			_status.put(id, status);
			System.out.println("UTM_CTR informa:  Drone " + id + " mudou de status para " + status );
			setChanged();
			notifyObservers(id);
		}
	}
	
	public String getStatusForID(int id){
		return _status.get(id);
	}


}
