package utm_v0;

import java.util.Observable;

class Drone extends Observable {
	
	private String self_status;
	private int id;
	
	public Drone(int id){
		this.id = id;
		this.self_status = "Rec�m criado";
	}

	public void setNewStatus(String novoStatus) {
		this.self_status = novoStatus;
		setChanged();
		notifyObservers();
	}
	
	public String getStatus() {
		return this.self_status;
	}
	
	public int getID(){
		return this.id;
	}
	
	public static void main(String[] args) {
		//poderia receber a nova edicao atraves de um recurso externo

		Drone drone1 = new Drone(1);
		Drone drone2 = new Drone(2);
		Drone drone3 = new Drone(3);
		GCS gcs1 = new GCS(1);
		GCS gcs2 = new GCS(2);
		GCS gcs3 = new GCS(3);
		
		UTM_CTR utm = UTM_CTR.INSTANCE;
		utm.addDrone(drone1);
		utm.addDrone(drone2);
		utm.addDrone(drone3);
		
		drone1.setNewStatus("Vou explodir em 10 segundos!");
		drone2.setNewStatus("Sem obst�culos num raio de 50 metros");
		drone3.setNewStatus("Uma horda de pass�ros � 400 metros da rota!");
		//RevistaInformatica revistaInformatica = new RevistaInformatica();		
		//Assinante1 assinante1 = new Assinante1(revistaInformatica);
		
		//revistaInformatica.setNovaEdicao(novaEdicao);
	}

}
