package utm_v0;

import java.util.Observable;
import java.util.Observer;

public class GCS implements Observer {
	
	String display;
	int id;
	
	public GCS(int ID){
		UTM_CTR.INSTANCE.addObserver(this);
		display = "Nada a informar";
		id = ID;
	}
	
	@Override
	public void update(Observable U, Object arg) {
		if(U instanceof UTM_CTR && (int) arg == id){
			UTM_CTR utm = (UTM_CTR) U;
			String status = utm.getStatusForID(this.id);
			display = "GCS"+ id  + ": Drone " + id + " novo status �: " + status;
			System.out.println(display );
		}
	}
	

}
