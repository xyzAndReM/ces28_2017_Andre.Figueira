package model;

import java.util.ArrayList;
import java.util.List;

public class Person {
	public interface PersonListener{
		void onPersonNameChanged();
	}
	
	public Person()
	{
	
	}
	
	public Person(String name)
	{
		this.setName(name);
	}

	public String getName()
	{
		System.out.println("A��o 5-> Getting name from person");
		return _name;
	}
	
	public void setName(String name)
	{
		System.out.println("A��o 3-> Setting new person name");
		String a = complexity(name);
		if(isAlpha(name) && Character.isUpperCase(name.charAt(0))){
			_name = a + " " + name;
		}
		else{
			System.out.println("<---Name WAS NOT changed--->");
		}
		fireOnNameChanged();
	}
	
	
	public boolean isAlpha(String name) {
	    return name.matches("[a-zA-Z]+");
	}
	
	public String complexity(String a){
		if(a.length() <= 5){
			return "VERMELHO";
		}
		else if (a.length() <= 10){
			return "AMARELO";
		}
		else return "VERDE";
	}
	
	
	
	

	public void addListener(PersonListener l)
	{
		this.listeners.add(l);
	}
	
	public void removeListener(PersonListener l)
	{
		this.listeners.remove(l);
	}
	
	private void fireOnNameChanged() {
		for(PersonListener l:this.listeners)
		{
			l.onPersonNameChanged();
		}
	}
	
	private String _name;
	private List<PersonListener> listeners = new ArrayList<PersonListener>();
}
