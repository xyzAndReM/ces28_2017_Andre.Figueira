package view;

public interface PersonDetailViewListener {

	public void changedButtonPressed();

	public void windowClosed();
}
